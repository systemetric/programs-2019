import nicerobot

R = nicerobot.Robot()

R.move(3)